const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session'); // นำเข้า express-session
const app = express();
const port = 3001;


app.use(express.static("public"));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ตั้งค่า body-parser เพื่อรับข้อมูลจากฟอร์ม
app.use(bodyParser.urlencoded({ extended: true }));

// ตั้งค่า EJS เป็น view engine สำหรับการ render หน้าเว็บ
app.set('view engine', 'ejs');

// ตั้งค่า express-session
app.use(session({
  secret: 'myid', // เปลี่ยนเป็นรหัสลับที่คุณเลือก
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 5 * 60 * 1000 } // 5 นาที 
}));

// สร้างการเชื่อมต่อกับ MySQL
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'mydb',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

//middleware สำหรับตรวจสอบสิทธิ์
function isAdmin(req, res, next) {
  if (req.session.user && (req.session.user.role === 'admin' || req.session.user.role === 'staff')) {
    return next(); // ผู้ใช้เป็น admin หรือ staff ให้ดำเนินการต่อไปยัง middleware ถัดไป
  }
  return res.status(403).send('Forbidden'); // ผู้ใช้ไม่ได้รับอนุญาต
}

// Route สำหรับหน้า Dashboard
app.get('/dashboard', isAdmin, (req, res) => {
  res.render('dashboard', { user: req.session.user }); // ส่งข้อมูลผู้ใช้ไปยังหน้า dashboard
});

// ใช้ middleware นี้สำหรับเส้นทางเฉพาะ
app.get('/admin', isAdmin, (req, res) => {
  res.render('admin'); // แสดงหน้า admin
});

// ตัวอย่างการแก้ไขเส้นทางผู้ใช้
app.get('/users', isAdmin, async (req, res) => {
  // โค้ดเพื่อดึงข้อมูลผู้ใช้
});


// Route แสดงฟอร์ม
app.get('/', (req, res) => {
  res.render('login');
});

// Route สำหรับหน้าแรก
app.get("/home", (req, res) => {
  // ตรวจสอบว่าใช้งานเซสชันหรือไม่
  if (req.session.user) {
    if (req.session.user.role === 'admin' || req.session.user.role === 'staff') {
      res.render('daskboard', { user: req.session.user }); // หน้าแดชบอร์ดสำหรับ admin และ staff
    } else {
      res.render('home', { user: req.session.user }); // หน้า home สำหรับผู้ใช้ทั่วไป
    }
  } else {
    res.redirect('/'); // ถ้าไม่ได้ล็อกอินให้กลับไปที่หน้า login
  }
});

// Route สำหรับการเข้าสู่ระบบ
app.get("/login", (req , res) => {
  res.render('login');
});

// Route สำหรับการลงทะเบียน
app.get("/register", (req , res) => {
  res.render('register');
});

// จัดการการส่งฟอร์มลงทะเบียน
app.post('/register', async (req, res) => {
  const { User, Password, Email, Phone, role = 'user' } = req.body; // Default to 'user'

// ตรวจสอบให้แน่ใจว่าข้อมูลมีค่าครบถ้วน
  if (!User || !Password || !Email || !Phone) {
    return res.status(400).send('Please fill in all fields');
  }

  try {
    const connection = await pool.getConnection();
    const [result] = await connection.execute(
      'INSERT INTO user (User, Password, Email, Phone, role) VALUES (?, ?, ?, ?, ?)',
      [User, Password, Email, Phone, role]
    );

    console.log(`New user created with ID: ${result.insertId}`);
    connection.release(); // คืน Connection ให้กับ Pool
    res.render('login',{ message: 'ลงทะเบียนสำเร็จ' }); // แสดงหน้า login หลังจากลงทะเบียนเสร็จ
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// จัดการข้อมูลฟอร์มล็อกอิน (POST)
app.post('/login', async (req, res) => {
  const { Email, Password } = req.body;

  try {
    // ดึงข้อมูลผู้ใช้รวมถึงบทบาท
    const [rows] = await pool.query('SELECT UserID, User, Password, role FROM user WHERE Email = ?', [Email]);

    if (rows.length > 0) {
      const user = rows[0];

      // เปรียบเทียบรหัสผ่านโดยตรง
      if (user.Password === Password) {
        // กำหนดเซสชันผู้ใช้รวมถึงบทบาท
        req.session.user = { UserID: user.UserID, User: user.User, role: user.role }; 
        console.log('Login successful, session user:', req.session.user);
        return res.redirect('/home');
      } else {
        return res.render('login', { message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' });
      }
    } else {
      return res.render('login', { message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).send('Internal Server Error');
  }
});


//daskboard-staff
app.get('/staff-dashboard', async (req, res) => {
  try {
      // ดึงข้อมูลสถิติ
      const [statistics] = await pool.query(`
          SELECT 
              (SELECT COUNT(*) FROM tickets) AS total,
              (SELECT COUNT(*) FROM tickets WHERE status = 'รอการตรวจสอบ') AS pending,
              (SELECT COUNT(*) FROM tickets WHERE status = 'แก้ไขแล้ว') AS resolved
      `);

      // ดึงข้อมูลรายการการแจ้งปัญหา
      const [tickets] = await pool.query('SELECT * FROM tickets');

      res.render('staff-dashboard', { statistics: statistics[0], tickets });
  } catch (err) {
      console.error('เกิดข้อผิดพลาด:', err);
      res.status(500).send('เกิดข้อผิดพลาดในการดึงข้อมูล');
  }
});

//สร้างเส้นทางใหม่เพื่อดึงข้อมูลสถิติจากฐานข้อมูล
app.get('/api/statistics', async (req, res) => {
  try {
      const connection = await mysql.createConnection({
          host: 'localhost',
          user: 'root',
          password: '',
          database: 'mydb'
      });

      // ดึงข้อมูลสถิติ
      const [totalTickets] = await connection.query('SELECT COUNT(*) AS total FROM tickets');
      const [pendingTickets] = await connection.query('SELECT COUNT(*) AS pending FROM tickets WHERE status = "รอการตรวจสอบ"');
      const [resolvedTickets] = await connection.query('SELECT COUNT(*) AS resolved FROM tickets WHERE status = "แก้ไขแล้ว"');

      await connection.end();

      res.json({
          total: totalTickets[0].total,
          pending: pendingTickets[0].pending,
          resolved: resolvedTickets[0].resolved
      });
  } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'เกิดข้อผิดพลาดในการดึงข้อมูลสถิติ' });
  }
});

app.post('/update-status', async (req, res) => {
  const { ticketId, status } = req.body;

  try {
      // เชื่อมต่อกับฐานข้อมูล
      const connection = await mysql.createConnection({
          host: 'localhost',
          user: 'root',
          password: '',
          database: 'mydb'
      });

      // อัพเดทสถานะในฐานข้อมูล
      const [result] = await connection.execute(
          'UPDATE tickets SET status = ? WHERE TicketID = ?',
          [status, ticketId]
      );

      // ปิดการเชื่อมต่อ
      await connection.end();

      // ตรวจสอบว่าการอัพเดทสำเร็จหรือไม่
      if (result.affectedRows > 0) {
          return res.json({ message: 'สถานะถูกอัพเดทเรียบร้อยแล้ว' });
      } else {
          return res.status(404).json({ message: 'ไม่พบตั๋วที่ระบุ' });
      }
  } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'เกิดข้อผิดพลาดในการอัพเดทสถานะ' });
  }
});





// เส้นทางหลัก (root route) - แสดงหน้ารายชื่อผู้ใช้พร้อมฟังก์ชันค้นหา
app.get('/users', async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/'); // ถ้าไม่ได้ล็อกอินให้กลับไปที่หน้า login
  }
  
  try {
    let query = 'SELECT * FROM users';
    let queryParams = [];

    if (req.query.search) {
      query += ' WHERE name LIKE ?';
      queryParams.push(`%${req.query.search}%`);
    }

    query += ' ORDER BY name ASC';

    const [rows] = await pool.query(query, queryParams);
    res.render('users', { users: rows, search: req.query.search || '' });
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// เส้นทางสำหรับการเพิ่มผู้ใช้
app.get('/add-user', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/'); // ถ้าไม่ได้ล็อกอินให้กลับไปที่หน้า login
  }
  res.render('add-user');
});

// จัดการการเพิ่มผู้ใช้ใหม่
app.post('/add-user', async (req, res) => {
  const { name, email } = req.body;
  try {
    await pool.query('INSERT INTO users (name, email) VALUES (?, ?)', [name, email]);
    res.redirect('/users');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// เส้นทางสำหรับการแก้ไขข้อมูลผู้ใช้
app.get('/users/:id/edit', async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/'); // ถ้าไม่ได้ล็อกอินให้กลับไปที่หน้า login
  }
  
  const { id } = req.params;
  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE id = ?', [id]);
    if (rows.length > 0) {
      res.render('edit-user', { user: rows[0] });
    } else {
      res.status(404).send('User not found');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// Route สำหรับแสดงข้อมูลตั๋ว
app.get('/tickets', async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/'); // ถ้าไม่ได้ล็อกอินให้กลับไปที่หน้า login
  }

  try {
    const [tickets] = await pool.query('SELECT * FROM tickets WHERE UserID = ?', [req.session.user.UserID]);

    // จัดรูปแบบวันที่ให้ไม่มีเวลา
    const formattedTickets = tickets.map(ticket => ({
      ...ticket,
      date: new Date(ticket.date).toLocaleDateString('en-US', {
        weekday: 'short', year: 'numeric', month: 'short', day: 'numeric'
      })
    }));

    res.render('helpdesktable', { tickets: formattedTickets });
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});




// สร้าง ticket ใหม่
app.get('/tickets/new', (req, res) => {
  if (!req.session.user) {
      return res.redirect('/'); // ถ้าไม่ได้ล็อกอินให้กลับไปที่หน้า login
  }

  // ดึงข้อมูลจากเซสชัน
  const { UserID, User } = req.session.user;
  

  // ส่งข้อมูลไปยังฟอร์ม
  res.render('ticket', {
      UserID: UserID, // ส่ง UserID ไปยังฟอร์ม
      User: User, // ส่งชื่อผู้ใช้งานไปยังฟอร์ม
      date: new Date().toISOString().split('T')[0]
  });
});


// บันทึก ticket ใหม่
app.post('/tickets', async (req, res) => {
  const { UserID, User, date, phone, category, Description } = req.body;

  try {
      // บันทึกข้อมูลลงในฐานข้อมูล
      const connection = await pool.getConnection();
      const [result] = await connection.execute(
          'INSERT INTO tickets (UserID, User, date, phone, category, Description) VALUES (?, ?, ?, ?, ?, ?)',
          [UserID, User, date, phone, category, Description]
      );

      console.log(`New ticket created with ID: ${result.insertId}`);
      connection.release(); // คืน Connection ให้กับ Pool
      res.redirect('/home'); // เปลี่ยนเส้นทางเมื่อบันทึกเสร็จ
  } catch (error) {
      console.error(error);
      res.status(500).send('Internal Server Error');
  }
});


// จัดการการอัปเดตข้อมูลผู้ใช้ด้วยวิธี PUT
app.put('/users/:id', async (req, res) => {
  const { id } = req.params;
  const { name, email } = req.body;

  console.log('Received data:', { id, name, email });

  try {
    if (!name || !email) {
      console.log('Missing required fields');
      return res.status(400).json({ error: 'Name and email are required' });
    }

    const [result] = await pool.query('UPDATE users SET name = ?, email = ? WHERE id = ?', [name, email, id]);
    
    console.log('Query result:', result);

    if (result.affectedRows > 0) {
      res.status(200).json({ message: 'User updated successfully' });
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ error: 'Internal Server Error', details: error.message });
  }
});

// จัดการการลบข้อมูลผู้ใช้ด้วยวิธี DELETE
app.delete('/users/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM users WHERE id = ?', [id]);
    res.status(200).json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// ตัวจัดการข้อผิดพลาดแบบ global
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!', details: err.message });
});

// Route สำหรับหน้า contact
app.get('/contact', (req, res) => {
  res.render('contact');
});

// logout
app.get('/logout', (req, res) => {
  req.session.destroy(err => {
      if (err) {
          return res.status(500).send('Could not log out');
      }
      res.redirect('/login');
  });
});

// เริ่มการทำงานของเซิร์ฟเวอร์
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
